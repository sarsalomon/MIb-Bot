--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mibot;
--
-- Name: mibot; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mibot WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Russian_Russia.1251';


ALTER DATABASE mibot OWNER TO postgres;

\connect mibot

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Appel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Appel" (
    id bigint NOT NULL,
    "chatId" bigint,
    passport text,
    phone text,
    description text,
    "districtId" bigint,
    status bigint,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Appel" OWNER TO postgres;

--
-- Name: Appel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Appel_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Appel_id_seq" OWNER TO postgres;

--
-- Name: Appel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Appel_id_seq" OWNED BY public."Appel".id;


--
-- Name: District; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."District" (
    id bigint NOT NULL,
    "nameUz" text,
    "nameRu" text,
    "nameOz" text,
    "nameEn" text,
    "descriptionUz" text,
    "descriptionRu" text,
    "descriptionOz" text,
    "descriptionEn" text,
    phone text,
    location text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    command text
);


ALTER TABLE public."District" OWNER TO postgres;

--
-- Name: District_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."District_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."District_id_seq" OWNER TO postgres;

--
-- Name: District_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."District_id_seq" OWNED BY public."District".id;


--
-- Name: Reception; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Reception" (
    id bigint NOT NULL,
    "chatId" bigint,
    passport text,
    phone text,
    description text,
    "districtId" bigint,
    status bigint,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Reception" OWNER TO postgres;

--
-- Name: Reception_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Reception_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Reception_id_seq" OWNER TO postgres;

--
-- Name: Reception_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Reception_id_seq" OWNED BY public."Reception".id;


--
-- Name: TelegramMembers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TelegramMembers" (
    id integer NOT NULL,
    "chatId" bigint NOT NULL,
    name text,
    phone text,
    "districtId" integer NOT NULL,
    lang text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."TelegramMembers" OWNER TO postgres;

--
-- Name: TelegramMembers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."TelegramMembers_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."TelegramMembers_id_seq" OWNER TO postgres;

--
-- Name: TelegramMembers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."TelegramMembers_id_seq" OWNED BY public."TelegramMembers".id;


--
-- Name: Users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Users" (
    id bigint NOT NULL,
    phone text NOT NULL,
    password text NOT NULL,
    role text NOT NULL,
    "districtId" bigint NOT NULL,
    status bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "chatId" bigint
);


ALTER TABLE public."Users" OWNER TO postgres;

--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Users_id_seq" OWNER TO postgres;

--
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- Name: Appel id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appel" ALTER COLUMN id SET DEFAULT nextval('public."Appel_id_seq"'::regclass);


--
-- Name: District id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."District" ALTER COLUMN id SET DEFAULT nextval('public."District_id_seq"'::regclass);


--
-- Name: Reception id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Reception" ALTER COLUMN id SET DEFAULT nextval('public."Reception_id_seq"'::regclass);


--
-- Name: TelegramMembers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TelegramMembers" ALTER COLUMN id SET DEFAULT nextval('public."TelegramMembers_id_seq"'::regclass);


--
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- Data for Name: Appel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Appel" (id, "chatId", passport, phone, description, "districtId", status, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Appel" (id, "chatId", passport, phone, description, "districtId", status, "createdAt", "updatedAt") FROM '$$PATH$$/3347.dat';

--
-- Data for Name: District; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."District" (id, "nameUz", "nameRu", "nameOz", "nameEn", "descriptionUz", "descriptionRu", "descriptionOz", "descriptionEn", phone, location, "createdAt", "updatedAt", command) FROM stdin;
\.
COPY public."District" (id, "nameUz", "nameRu", "nameOz", "nameEn", "descriptionUz", "descriptionRu", "descriptionOz", "descriptionEn", phone, location, "createdAt", "updatedAt", command) FROM '$$PATH$$/3353.dat';

--
-- Data for Name: Reception; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Reception" (id, "chatId", passport, phone, description, "districtId", status, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Reception" (id, "chatId", passport, phone, description, "districtId", status, "createdAt", "updatedAt") FROM '$$PATH$$/3351.dat';

--
-- Data for Name: TelegramMembers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TelegramMembers" (id, "chatId", name, phone, "districtId", lang, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."TelegramMembers" (id, "chatId", name, phone, "districtId", lang, "createdAt", "updatedAt") FROM '$$PATH$$/3349.dat';

--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Users" (id, phone, password, role, "districtId", status, "createdAt", "updatedAt", "chatId") FROM stdin;
\.
COPY public."Users" (id, phone, password, role, "districtId", status, "createdAt", "updatedAt", "chatId") FROM '$$PATH$$/3355.dat';

--
-- Name: Appel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Appel_id_seq"', 2, true);


--
-- Name: District_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."District_id_seq"', 23, true);


--
-- Name: Reception_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Reception_id_seq"', 1, true);


--
-- Name: TelegramMembers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."TelegramMembers_id_seq"', 5, true);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Users_id_seq"', 25, true);


--
-- Name: Appel Appel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appel"
    ADD CONSTRAINT "Appel_pkey" PRIMARY KEY (id);


--
-- Name: District District_descriptionUz_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."District"
    ADD CONSTRAINT "District_descriptionUz_key" UNIQUE ("descriptionUz");


--
-- Name: District District_nameUz_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."District"
    ADD CONSTRAINT "District_nameUz_key" UNIQUE ("nameUz");


--
-- Name: District District_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."District"
    ADD CONSTRAINT "District_pkey" PRIMARY KEY (id);


--
-- Name: Reception Reception_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Reception"
    ADD CONSTRAINT "Reception_pkey" PRIMARY KEY (id);


--
-- Name: TelegramMembers TelegramMembers_chatId_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TelegramMembers"
    ADD CONSTRAINT "TelegramMembers_chatId_key" UNIQUE ("chatId");


--
-- Name: TelegramMembers TelegramMembers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TelegramMembers"
    ADD CONSTRAINT "TelegramMembers_pkey" PRIMARY KEY (id);


--
-- Name: Users Users_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_phone_key" UNIQUE (phone);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

